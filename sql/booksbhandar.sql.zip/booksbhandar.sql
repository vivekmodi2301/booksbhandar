-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 25, 2016 at 05:35 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `booksbhandar`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `username` varchar(75) DEFAULT NULL,
  `password` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'modiv2301@gmail.com', '9024555623'),
(2, 'modiv12@yahoo.com', '9462193854'),
(3, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `catid` int(3) DEFAULT NULL,
  `pid` int(3) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `photo` varchar(100) NOT NULL,
  `book` varchar(200) NOT NULL,
  `download` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=83 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `catid`, `pid`, `name`, `author`, `photo`, `book`, `download`) VALUES
(3, 4, 1, 'Coexist: Keegans chronicles', 'Julia Crane', '1458726160_coexist-crane.jpg', '1458726160_Coexist-obooko-tya0096.pdf', 5),
(2, 4, 1, 'The Silver Ring', 'Robert Swartwood', '1458726583_silverringswartwood.jpg', '1458726583_SilverRing-obooko-tya0047.pdf', 1),
(5, 3, 2, 'Direct Action', 'Tom Fitzgerald', '1458727133_directaction.gif', '1458727133_directaction.pdf', 1),
(6, 2, 3, 'Return 2 Terror with Love', 'David Lovett', '1458727669_return-2-terror-lovett.jpg', '1458727669_Return-2-Terror-obooko-thr0288.pdf', 4),
(7, 1, 8, 'Crush', 'Chrissie Peebles', '1459674939_crush-peebles.jpg', '1459674939_Crush-obooko-rom0256.pdf', 0),
(8, 1, 8, 'Blind Sight', 'Kait Nolan', '1459675089_blindsight_nolan.jpg', '1459675089_Blindsight-obooko-rom140.pdf', 0),
(9, 1, 8, 'Dirty Genes', 'Esther Minskoff', '1459675235_dirty-genes-minskoff.jpg', '1459675235_DirtyGenes-obooko-rom0190.pdf', 0),
(10, 1, 8, 'Katie''s Hope', 'Lizzy Ford', '1459677262_katies-hope-ford.jpg', '1459677262_KatiesHope-obooko-rom0165.pdf', 0),
(11, 1, 8, 'kiera''s Moon', 'Lizzy Ford', '1459677414_kieras-moon-ford.jpg', '1459677414_KierasMoon-obooko-rom0163.pdf', 0),
(12, 2, 8, 'The May Day Murders', 'Scott Wittenburg', '1459677659_may-day-wittenburg.jpg', '1459677659_MayDayMurders-obooko-thr0168.pdf', 0),
(13, 2, 8, 'Heart of a Spider', 'Mark  Stewart', '1459677760_heart-spider-stewart.jpg', '1459677760_HeartSpider-obooko-thr0150.pdf', 0),
(14, 2, 8, '200 Steps Down', 'Morris Kenyon', '1459677867_200-steps-kenyon.jpg', '1459677867_200StepsDown-obooko-thr0182.pdf', 2),
(15, 2, 8, 'Pure Mad', 'Gary J Byrnes', '1459678063_pure_mad_byrnes.jpg', '1459678063_PureMad-obooko-thr0099.pdf', 0),
(16, 3, 8, 'I/D', 'Leon Berger', '1459833620_idleonberger.jpg', '1459833620_ID-LeonBerger-obooko-actad0005.pdf', 0),
(17, 3, 8, 'Fire On The Horizon', 'Daniel Derrett', '1459833751_fothderrett.jpg', '1459833751_FOTH-obooko-actad0009.pdf', 0),
(18, 3, 8, 'Across The Pond', 'Michael McCromick', '1459833911_across-pond-mccormick.jpg', '1459833911_Across-the-Pond-obooko-adv0047.pdf', 0),
(19, 3, 8, 'Don''t Ask', 'B. K. Dell', '1459834004_dont_ask_dell.jpg', '1459834004_DontAsk-obooko-adv0021.pdf', 0),
(20, 4, 8, 'The Spring', 'J. M. Reep', '1459834141_thespringreep.jpg', '1459834141_TheSpring_Reep-obooko-tya0013.pdf', 0),
(21, 4, 8, 'Leah ', 'J. M. Reep', '1459834227_leahreep.jpg', '1459834227_Leah-reep-obooko-tya0012.pdf', 0),
(22, 4, 8, 'Mind+ Body', 'Aaron Dunlap', '1459834370_mindbodydun.jpg', '1459834370_MindBody-obooko-thr0036.pdf', 0),
(23, 5, 8, 'Sunset', 'Timothy J. Sparklin', '1459834561_sunsetsparklin.jpg', '1459834561_sunset-obooko-hor0003.pdf', 0),
(24, 5, 8, 'The Haunted Way', 'Neil Wesson', '1459834673_hauntedwaywesson.jpg', '1459834673_HauntedWay-obooko-hor0007.pdf', 0),
(25, 5, 8, 'Curel World', 'Jhon R Morgan', '1459834777_cruelworldmorgan.jpg', '1459834777_CruelWorld-obooko-hor0014.pdf', 0),
(26, 5, 8, 'Hard', 'Jack R. Dunn', '1459834966_hardjackdunn.jpg', '1459834966_Hard-obooko-hor0021.pdf', 0),
(27, 5, 8, 'Shock Therapy', 'Edgar Arbogast', '1459835067_shock_arbogast.jpg', '1459835067_ShockTherapy-obooko-hor0028.pdf', 0),
(28, 6, 8, 'Starfish ', 'Peter Watts', '1459835271_starfishpeterwatts.jpg', '1459835271_PeterWatts_Starfish-scifi0023.pdf', 0),
(29, 6, 8, 'Under a Violet Sky', 'Graeme Winton', '1459835406_violet-sky-winton.jpg', '1459835406_VioletSky-obooko-fan0124.pdf', 0),
(30, 6, 8, 'Star Dragon', 'Mike Brotherton', '1459853305_stardragonbritherton.jpg', '1459853305_stardragon-obooko-scifi0024.pdf', 0),
(31, 6, 2, 'Deviations: Second Covenant', 'Elissa Malchon', '1459853513_second_covenant_malcohn.jpg', '1459853513_SecondCovenant-obooko-scifi0113.pdf', 0),
(32, 6, 2, 'The Blue Ball', 'Wayne Miller', '1459853628_blueball.jpg', '1459853628_ThisBlueBall-obooko.pdf', 0),
(33, 7, 2, 'Deviations: Telzodo', 'Elissa Malchon', '1459854011_telzodo_malcohn.jpg', '1459854011_TelZodo-obooko-scifi0094.pdf', 0),
(34, 7, 2, 'Bridge of Stone and Magic ', 'Trevor Hopkins', '1459854237_bridge_stone_magic.jpg', '1459854237_BridgeStoneMagic-obooko-fan0047.pdf', 0),
(35, 7, 2, 'Death on The New Bridge', 'Trevor Hopkins', '1459854506_deathonbridge.jpg', '1459854506_death-on-the-new-bridge.pdf', 0),
(36, 7, 2, 'Bridge at War', 'Trevor Hopkins', '1459854635_bridgeatwar.jpg', '1459854635_bridge-at-war.pdf', 0),
(37, 7, 2, 'Soul Keeper ', 'Jaye Patrick', '1459855713_soulkeeperpatrick.jpg', '1459855713_SoulKeeper-obooko-fan0023.pdf', 0),
(38, 8, 2, 'The Fox', 'Arlene Radasky', '1459862891_thefox01.jpg', '1459862891_The-Fox.pdf', 0),
(39, 8, 2, 'Son of Sparta', 'Sara Reinke', '1459863460_sonofsparta.jpg', '1459863460_Son_of_Sparta_Reinke.pdf', 0),
(40, 8, 2, 'The Tide Mill', 'Richard Herley', '1459863612_tidemillherley.jpg', '1459863612_TheTideMill-obooko-per0005.pdf', 0),
(41, 8, 2, 'The Fox and The Bear', 'L. A. Wilson', '1459863776_silurianwilson.jpg', '1459863776_Silurian1-obooko-per0009.pdf', 0),
(42, 8, 2, 'Murder at Zero Hour', '', '1459863855_murder-westwood.jpg', '1459863855_MurderAtZeroHour-obooko-thr0161.pdf', 0),
(43, 9, 2, 'The Golden Calf', 'Henry Baum', '1459864686_goldencalfbaum.jpg', '1459864686_ASP_TheGoldenCalf_HenryBaum.pdf', 0),
(44, 9, 2, 'Black and White', 'Lewis Shiner', '1459864790_blackandwhite.jpg', '1459864790_blackwhite.pdf', 0),
(45, 9, 2, 'The Judas Tree', 'Patricia Le Roy', '1459864919_judas_tree_le_roy.jpg', '1459864919_TheJudasTree-obooko-gen0130.pdf', 0),
(46, 9, 2, '12 Steps', 'Darren R. Hawkins', '1459865040_12stepshawkins.jpg', '1459865040_12Steps-obooko-gen0051.pdf', 0),
(47, 9, 2, '54', 'Wu Ming', '1459865134_54wuming.jpg', '1459865134_54-wuming-obooko-gen0050.pdf', 0),
(48, 10, 2, 'Diamonds in The Sky', 'Mike Brotherton', '1459865291_diamondsbrothert.jpg', '1459865291_diamonds-obooko-shortc0023.pdf', 0),
(49, 10, 2, 'Magic For Beginners', 'Kelly Link', '1459865380_magicforbeginners.jpg', '1459865380_MagicBeginners-obooko-shortc0002.pdf', 0),
(51, 10, 2, 'This is Not The End', 'Shelby Davis', '1459865555_nottheendshelby.jpg', '1459865555_NotTheEnd-obooko-shortc0034.pdf', 0),
(52, 10, 2, 'The End, My Frined', 'Gary J Byrnes', '1459922696_the_end_byrnes.jpg', '1459922696_TheEndMyFriend-obooko-shortc0045.pdf', 0),
(53, 10, 2, 'Thirteen', 'Jonny Newell', '1459922808_thirteen-newell.jpg', '1459922808_Thirteen-obooko-shortc0108.pdf', 0),
(54, 12, 2, 'Gone With The Trash', 'Brad Rines', '1459924160_gonewithtrash.gif', '1459924160_gone-with-trash-obooko-hum0006.pdf', 0),
(55, 12, 3, 'Barry''s World', 'Dave Jenvey', '1459924496_barrysworldjenvey.jpg', '1459924496_BarrysWorld-obooko-hum0008.pdf', 0),
(56, 12, 3, 'Mom Letters ', 'Jack Brackitt', '1459924581_momlettersjack.gif', '1459924581_MomLetters-obooko-hum0015.pdf', 0),
(57, 12, 3, 'Odd Jobs', 'Timothy A. Boling', '1459924687_oddjobsbowling.jpg', '1459924687_OddJobs-obooko-hum0012.pdf', 0),
(58, 12, 3, 'Crazy ', 'Leo Vine-Knight', '1459924764_crazy-vine-knight.jpg', '1459924764_Crazy-obooko-hum0037.pdf', 0),
(59, 13, 3, 'The Bad Seed', 'Dee Sunshine', '1459925119_badseeddee.gif', '1459925119_TheBadSeed-obooko-poet0021.pdf', 0),
(60, 13, 3, 'Post Digital', 'J.D. Casten', '1459925313_posdigital.jpg', '1459925313_PostDigitalRevelation.pdf', 0),
(61, 13, 3, 'Penn ', 'Sara Berkeley', '1459925411_pennpoemsberkeley.jpg', '1459925411_penn-obooko-poet0008(1).pdf', 0),
(62, 13, 3, 'Silent Vocies', 'Wole Adedoyin', '1459925509_silent-voices-adedoyin.jpg', '1459925509_SilentVoices-obooko-poetry0116.pdf', 0),
(63, 13, 3, 'Confession', 'Joel Chua Hiang Yang', '1459925628_confession-yang.jpg', '1459925628_Confession-obooko-poetry0072.pdf', 0),
(64, 13, 3, 'Preceptions of Truth', 'Rhys Corey Judd', '1459926975_perceptions-judd.jpg', '1459926975_PerceptionsTruth-obooko-poetry0090.pdf', 0),
(65, 14, 3, 'Living From The Heart', 'Nirmala', '1459927245_livingfromheart.jpg', '1459927245_Living_from_the_Heart.pdf', 0),
(66, 14, 3, 'Nothing Persnol', 'Nirmala', '1459927311_nothingpersonal.jpg', '1459927311_Nothing-Personal.pdf', 0),
(67, 14, 3, 'The Scince Of Getting Rich', 'Wallace D. Wattels', '1459927445_sogrwattles.jpg', '1459927445_SOGR-obooko-A5.pdf', 0),
(68, 14, 3, 'The Great Simulator', 'David McCready', '1459927559_great_simulator_mccready.gif', '1459927560_GreatSimulator1-obooko-mind0022.pdf', 0),
(69, 14, 3, 'Where are the Zombies', 'Kar Y. Lee', '1459927643_zombies_kar_lee.gif', '1459927643_WhereZombies-obooko-mind0021.pdf', 0),
(70, 16, 8, 'Only The Darkness', 'Mike Crowson', '1459931633_only_darkness_crowson.jpg', '1459931633_Darkness-obooko-new0014.pdf', 0),
(71, 16, 8, 'Heat Stroke', 'Mike Crowson', '1459931800_heatstroke_crowson.jpg', '1459931800_HeatStroke-obooko-new0013.pdf', 0),
(72, 16, 8, 'Dream Interpretations', 'Gustavus Hindman Miller', '1459931907_dreams_obooko.jpg', '1459931907_Dreams-obooko-new0016.pdf', 0),
(73, 16, 8, 'The Human Aura', 'Swami Panchadasi', '1459931993_human-aura-panchadasi.jpg', '1459931993_HumanAura-obooko-new0021.pdf', 0),
(74, 16, 8, 'God', 'Manjunath R.', '1459932096_god-manjunath-r.jpg', '1459932096_GOD-Manjunath-R-obooko-new0048.pdf', 0),
(75, 20, 4, 'Blood Sweat and Tea', 'Tom Reynolds', '1459932632_blood-sweat-tea-reynolds.jpg', '1459932632_Blood-Sweat-Tea-obooko-mem0031.pdf', 0),
(76, 20, 4, 'True Calling', 'Laura Marie Patterson', '1459932721_true-calling-patterson.jpg', '1459932721_TrueCalling-obooko-hea0028.pdf', 0),
(77, 20, 4, 'Girl on The Home Front', 'Ian Billingsley', '1459932816_girls-bilingsley.gif', '1459932816_GirlsHomeFront-obooko-mem0012.pdf', 0),
(78, 20, 4, 'Worth Fighting For', 'Gabrielle Tennenbaum Radnor', '1459932998_worth-fighting-for-radnor.jpg', '1459932998_WorthFightingFor-obooko-mem0025.pdf', 0),
(79, 20, 4, 'Bad Hare Days', 'Jhon Fitzgerald', '1459933129_bad-hare-days.jpg', '1459933129_BadHareDays-obooko-mem0013.pdf', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'Romance'),
(2, 'Crime, Thriller and mystery'),
(3, 'Action and Adventure'),
(4, 'Teen and Ya Fiction'),
(5, 'Horror and supernatural'),
(6, 'Scince Fiction Books'),
(7, 'Fantacy Fiction Books'),
(8, 'Historical Fiction Novels'),
(9, 'Genral, Drama, Literary'),
(10, 'Short Story Collection'),
(12, 'Funny and Humorous'),
(13, 'Poetry Collections'),
(14, 'Mind, Body, Spirituality'),
(15, 'NewAge, Astrology, Occult'),
(16, 'Memoir and Biography');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `bid` int(5) DEFAULT NULL,
  `pid` int(5) DEFAULT NULL,
  `comment` text,
  PRIMARY KEY (`id`),
  KEY `bid` (`bid`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `bid`, `pid`, `comment`) VALUES
(1, 6, 8, 'this is the best book i have ever read. this is book is must read book'),
(6, 5, 8, 'h8uhiooi'),
(5, 6, 9, 'Best book iuvhiufsvifsu ugheui svguhvisuh vsgo vsiuhys vuihsuvg vhfiuvyusgyvuidv vsg v hiuoiBest book iuvhiufsvifsu ugheui svguhvisuh vsgo vsiuhys vuihsuvg vhfiuvyusgyvuidv vsg v hiuoiBest book iuvhiufsvifsu ugheui svguhvisuh vsgo vsiuhys vuihsuvg vhfiuvyusgyvuidv vsg v hiuoiBest book iuvhiufsvifsu ugheui svguhvisuh vsgo vsiuhys vuihsuvg vhfiuvyusgyvuidv vsg v hiuoiBest book iuvhiufsvifsu ugheui svguhvisuh vsgo vsiuhys vuihsuvg vhfiuvyusgyvuidv vsg v hiuoiBest book iuvhiufsvifsu ugheui svguhvisuh vsgo vsiuhys vuihsuvg vhfiuvyusgyvuidv vsg v hiuoiBest book iuvhiufsvifsu ugheui svguhvisuh vsgo vsiuhys vuihsuvg vhfiuvyusgyvuidv vsg v hiuoiBest book iuvhiufsvifsu ugheui svguhvisuh vsgo vsiuhys vuihsuvg vhfiuvyusgyvuidv vsg v hiuoi'),
(7, 79, 8, '');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE IF NOT EXISTS `likes` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `bid` int(5) DEFAULT NULL,
  `pid` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bid` (`bid`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `likes`
--


-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `gender` enum('m','f') DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `time` int(30) NOT NULL,
  `username` varchar(60) DEFAULT NULL,
  `password` varchar(35) DEFAULT NULL,
  `valid` enum('y','n') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `name`, `gender`, `mobile`, `photo`, `time`, `username`, `password`, `valid`) VALUES
(8, 'vivek modi', 'm', '9024555623', '1459672136_vivek.png', 1459496527, 'modiv2301@gmail.com', '9024555623', 'y'),
(2, 'gitika modi', 'f', '9024197412', '1458654594_GEETIKA MODI.jpg', 1458654526, 'gitikamodi9024@gmail.com', '9024197412', 'n'),
(3, 'khushboo modi', 'f', '9024182823', '1458654664_img239 - Copy.jpg', 1458654594, 'khushboomodi2823@gmail.com', '9024182823', 'n'),
(4, 'manohar lal modi', 'm', '9251737789', '1458654736_IMG-20150128-WA0001.jpg', 1458654664, 'manlalmodi7789@gmail.com', '9251737789', 'n'),
(5, 'seema modi', 'f', '9462193854', '1458654776_IMG-20150127-WA0041.jpg', 1458654736, 'semodi3854@gmail.com', '9462193854', 'n'),
(9, 'vivek modi', 'm', '9462193854', '1459672472_vivek.png', 1459496685, 'modiv12@yahoo.com', '9024555623', 'n'),
(7, 'priyanka arora', 'f', '9660785084', '1458654899_IMG-20150525-WA0034.jpg', 1458654828, 'pinkupinki084@gmail.com', '9660785084', 'n');

-- --------------------------------------------------------

--
-- Table structure for table `query`
--

CREATE TABLE IF NOT EXISTS `query` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `query` text,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `query`
--

INSERT INTO `query` (`id`, `query`, `name`, `email`) VALUES
(1, 'hi this is vivek modi', 'vivek  modi', 'modiv2301@gmail'),
(2, 'hey i want to search by author name too. or a category of authors so we can find books more eaisly', 'vivek modi', 'modiv12@yahoo.c');
